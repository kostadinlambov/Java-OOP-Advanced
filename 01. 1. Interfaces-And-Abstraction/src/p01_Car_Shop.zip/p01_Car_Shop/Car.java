package p01_Car_Shop;

public interface Car {
    Integer TIRES = 4;

    String getModel();

    String getColor();

    int getHorsePower();
}
