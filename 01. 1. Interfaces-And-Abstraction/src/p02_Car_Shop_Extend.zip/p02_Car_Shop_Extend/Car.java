package p02_Car_Shop_Extend;

public interface Car {
    Integer TIRES = 4;

    String getModel();

    String getColor();

    int getHorsePower();
}
