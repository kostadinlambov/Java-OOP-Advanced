package p03_Say_Hello;

public interface Person {

    String getName();

    String sayHello();

}
