package p04_Say_Hello_Extend;

public interface Person {

    String getName();

    String sayHello();

}
