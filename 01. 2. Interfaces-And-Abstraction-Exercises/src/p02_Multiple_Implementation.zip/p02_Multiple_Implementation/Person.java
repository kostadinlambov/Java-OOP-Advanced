package p02_Multiple_Implementation;

public interface Person {

    String getName();
   // void setName(String name);

    int getAge();
   // void setAge(int age);
}
