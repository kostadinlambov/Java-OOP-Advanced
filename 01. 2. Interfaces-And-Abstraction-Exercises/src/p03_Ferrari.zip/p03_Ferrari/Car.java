package p03_Ferrari;

public interface Car {

    String brakes();
    String gssPedal();

    void setDriverName(String driverName);
    String getDriverName();
}
