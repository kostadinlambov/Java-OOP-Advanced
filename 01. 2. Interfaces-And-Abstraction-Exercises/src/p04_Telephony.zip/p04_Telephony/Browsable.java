package p04_Telephony;

public interface Browsable {

    void browseInWeb(String url);
}
