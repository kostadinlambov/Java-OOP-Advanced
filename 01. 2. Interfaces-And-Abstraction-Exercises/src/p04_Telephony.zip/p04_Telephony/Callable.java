package p04_Telephony;

public interface Callable {

    void callPhones(String number);
}
