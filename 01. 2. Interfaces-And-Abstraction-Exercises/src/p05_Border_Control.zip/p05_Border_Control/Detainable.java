package p05_Border_Control;

public interface Detainable {

    //boolean detain(String id, String digitToCompare);
    boolean detain(String digitToCompare);
    String getId();
}
