package p06_Birthday_Celebrations;

public interface Identificatable {
    boolean checkYearOfBirth(String yearToCompare);
    String getBirthday();
}
