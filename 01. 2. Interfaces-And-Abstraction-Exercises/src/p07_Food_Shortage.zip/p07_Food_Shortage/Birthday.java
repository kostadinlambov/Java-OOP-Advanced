package p07_Food_Shortage;

public interface Birthday {
    boolean checkYearOfBirth(String yearToCompare);
    String getBirthday();
}
