package p07_Food_Shortage;

public interface Buyer {
   void  buyFood();
   int getFood();
   String getName();
}
