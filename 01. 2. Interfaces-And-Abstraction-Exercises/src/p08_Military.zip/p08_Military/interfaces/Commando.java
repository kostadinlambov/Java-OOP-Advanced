package p08_Military.interfaces;

import p08_Military.interfaces.Mission;

import java.util.Collection;

public interface Commando {
    Collection<Mission> getMissions();
}
