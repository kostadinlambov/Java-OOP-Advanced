package p08_Military.interfaces;

import p08_Military.interfaces.Repair;

import java.util.Collection;

public interface Engineer {
    Collection<Repair> getRepairs();
}
