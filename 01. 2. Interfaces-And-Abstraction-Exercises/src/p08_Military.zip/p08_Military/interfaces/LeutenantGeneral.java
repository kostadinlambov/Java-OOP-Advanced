package p08_Military.interfaces;

import p08_Military.interfaces.Private;

import java.util.Collection;

public interface LeutenantGeneral {
    Collection<Private> getPrivates();
}
