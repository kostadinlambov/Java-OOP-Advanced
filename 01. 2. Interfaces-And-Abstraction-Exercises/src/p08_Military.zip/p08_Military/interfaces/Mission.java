package p08_Military.interfaces;

public interface Mission {
    String getCodeName();
    String getState();
    void completeMission();
}
