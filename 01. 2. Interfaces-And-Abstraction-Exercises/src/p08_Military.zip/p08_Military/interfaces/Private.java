package p08_Military.interfaces;

import p08_Military.interfaces.Soldier;

public interface Private extends Soldier {
    double getSalary();
}
