package p08_Military.interfaces;

public interface Soldier {

    String getFirstName();

    String getLastName();

    int getId();
}
