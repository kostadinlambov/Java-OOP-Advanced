package p08_Military.interfaces;

import p08_Military.interfaces.Soldier;

public interface SpecialisedSoldier extends Soldier {
    String getCorps();
}
