package p08_Military.interfaces;

public interface Spy {
    String getCodeNumber();
}
