package p08_Military_Elite.interfaces;

import java.util.Collection;

public interface Commando {
    Collection<Mission> getMissions();
}
