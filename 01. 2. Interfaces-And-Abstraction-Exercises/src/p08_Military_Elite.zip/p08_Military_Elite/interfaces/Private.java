package p08_Military_Elite.interfaces;

public interface Private extends Soldier {
    double getSalary();
}
