package p08_Military_Elite.interfaces;

public interface Repair {

    String getPartName();

    int getHours();
}
