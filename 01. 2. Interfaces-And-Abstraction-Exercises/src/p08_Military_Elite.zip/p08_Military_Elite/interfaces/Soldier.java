package p08_Military_Elite.interfaces;

public interface Soldier {

    String getFirstName();

    String getLastName();

    int getId();
}
