package p08_Military_Elite.interfaces;

public interface SpecialisedSoldier extends Soldier {
    String getCorps();
}
