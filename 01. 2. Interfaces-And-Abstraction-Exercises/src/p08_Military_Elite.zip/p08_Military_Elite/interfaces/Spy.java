package p08_Military_Elite.interfaces;

public interface Spy {
    String getCodeNumber();
}
