package p09_Collection_Hierarchy;


public interface AddCollection<T> {

    int add(T element);
}
