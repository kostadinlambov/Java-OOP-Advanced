package p09_Collection_Hierarchy;

public interface AddRemoveCollection<T> extends AddCollection<T> {
    T remove();
}
