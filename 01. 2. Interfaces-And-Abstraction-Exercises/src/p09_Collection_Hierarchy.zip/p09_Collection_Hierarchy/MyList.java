package p09_Collection_Hierarchy;

public interface MyList<T> extends AddRemoveCollection<T> {

    int size();
}
