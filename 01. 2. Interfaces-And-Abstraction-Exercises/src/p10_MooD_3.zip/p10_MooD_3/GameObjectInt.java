package p10_MooD_3;

public interface GameObjectInt {

}
