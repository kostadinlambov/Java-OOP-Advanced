package p08_Custom_List_Sorter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomList<T extends Comparable<T>> {

    private List<T> listOfElements;

    public CustomList() {
        this.listOfElements = new ArrayList<>();
    }


    public void add(T element) {
        this.listOfElements.add(element);
    }

    public void remove(int index) {
        this.listOfElements.remove(index);
    }

    public boolean contains(T element) {
        return this.listOfElements.contains(element);
    }

    public void swap( int firstIndex, int secondIndex) {

        T firstElement = this.listOfElements.get(firstIndex);
        T secondElement = this.listOfElements.get(secondIndex);
        this.listOfElements.set(secondIndex, firstElement);
        this.listOfElements.set(firstIndex, secondElement);
    }

    public int countGreaterThan(T elementToCompare) {

        int counter = 0;
        for (T listOfElement : this.listOfElements) {
            if (listOfElement.compareTo(elementToCompare) > 0) {
                counter++;
            }
        }

        return counter;
    }

    public T getMax() {
        return  Collections.max(this.listOfElements);
    }


    public T getMin() {
       return  Collections.min(this.listOfElements);
    }

    public void sort() {
       this.listOfElements.sort(Comparable::compareTo);
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        for (T element : listOfElements) {
            sb.append(element).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }

}
