package p10_Tuple;

public interface Tuple<T, E> {

    T getFirstObject();

    E getSecondObject();
}
