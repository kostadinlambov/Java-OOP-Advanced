package p11_Threeuple;

public interface Threeuple<T, E, D> {
    T getFirstObject();

    E getSecondObject();

    D getThirdObject();
}
