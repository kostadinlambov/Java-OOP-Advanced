package p01_ListyIterator;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ListyIterator  {

    private List<String> collection;
    private int index;

    public ListyIterator(String... collection) {
        this.setCollection(collection);
        this.index = 0;
    }

    public Collection<String> getCollection() {
        return this.collection;
    }

    private void setCollection(String... collection) {
        this.collection = Arrays.asList(collection);
    }

    public boolean move(){
        if(this.index < this.collection.size()-1){
            this.index++;
            return true;
        }
        return false;
    }


    public boolean hasNext(){
        if(this.index < this.collection.size()-1){
            return true;
        }
        return false;
    }

    public void print(){
        if(this.collection.size() == 0){
          throw new IllegalArgumentException("Invalid Operation!");
        }
        System.out.println(collection.get(this.index));
    }
}
