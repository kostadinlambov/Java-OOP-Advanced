package p02_Collection;

public interface ListyIterator {
    boolean move();

    boolean hasNext();

    void print();

    void printAll();
}
