package p08_Pet_Clinics.entities.interfaces;

public interface Pet {
    String getName();

    int getAge();

    String getKind();
}
