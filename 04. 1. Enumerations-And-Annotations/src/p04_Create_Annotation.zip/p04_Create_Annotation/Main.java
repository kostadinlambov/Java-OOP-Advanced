package p04_Create_Annotation;

public class Main {
    public static void main(String[] args) {


    }
}
