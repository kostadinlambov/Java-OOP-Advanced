package p05_Coding_Tracker;

public class Main {
    public static void main(String[] args) {
        Tracker.printMethodsByAuthor(Tracker.class);
        System.out.println(Tracker.class);
    }
}
