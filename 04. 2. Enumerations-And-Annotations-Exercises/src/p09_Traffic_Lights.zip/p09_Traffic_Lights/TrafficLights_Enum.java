package p09_Traffic_Lights;

public enum TrafficLights_Enum {
    RED, GREEN, YELLOW;
}
