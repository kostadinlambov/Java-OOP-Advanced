package p10_Inferno_Infinity.controller;

import p10_Inferno_Infinity.entities.enumerations.WeaponType;
import p10_Inferno_Infinity.entities.implementations.WeaponsImpl;
import p10_Inferno_Infinity.entities.interfaces.Weapon;

import java.util.LinkedHashMap;
import java.util.Map;

public class WeaponsManager {

    private Map<String, Weapon> weaponMap;

    public WeaponsManager() {
        this.weaponMap = new LinkedHashMap<>();
    }


    public void createWeapon(String name, WeaponType weaponType) {
        Weapon weapon = new WeaponsImpl(name, weaponType);
        weaponMap.putIfAbsent(name, weapon);
    }


    public void addGem(String weaponName, int socketIndex, String gemType) {
        if (weaponMap.containsKey(weaponName)) {
            Weapon weapon = weaponMap.get(weaponName);
            weapon.addGem(socketIndex, gemType);
        }
    }

    public void removeGem(String weaponName, int socketIndex) {
        if (weaponMap.containsKey(weaponName)) {
            Weapon weapon = weaponMap.get(weaponName);
            weapon.removeGem(socketIndex);
        }
    }

    public void print(String weaponName) {
        if (weaponMap.containsKey(weaponName)) {
            Weapon weapon = weaponMap.get(weaponName);
            System.out.println(weapon);
        }
    }
}
