package p10_Inferno_Infinity.entities;

public abstract class Weapons {

    private String name;
    private int minDamage;
    private int maxDamage;
    private int numberOfSockets;

    public Weapons(String name, int minDamage, int maxDamage, int numberOfSockets) {
        this.setName(name);
        this.setMinDamage(minDamage);
        this.setMaxDamage(maxDamage);
        this.setNumberOfSockets(numberOfSockets);
    }

    private void setName(String name) {
        this.name = name;
    }

    protected void setMinDamage(int minDamage) {
        this.minDamage = minDamage;
    }

    protected void setMaxDamage(int maxDamage) {
        this.maxDamage = maxDamage;
    }

    protected void setNumberOfSockets(int numberOfSockets) {
        this.numberOfSockets = numberOfSockets;
    }

//
//    protected void setMaxDamage(int maxDamage) {
//        this.maxDamage = maxDamage;
//    }
//
//    protected void setNumberOfSockets(int numberOfSockets) {
//        this.numberOfSockets = numberOfSockets;
    //}
}
