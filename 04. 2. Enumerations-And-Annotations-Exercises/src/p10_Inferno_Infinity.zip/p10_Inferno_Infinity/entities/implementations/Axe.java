package p10_Inferno_Infinity.entities.implementations;

import p10_Inferno_Infinity.entities.Weapons;
import p10_Inferno_Infinity.entities.enumerations.WeaponType;

public class Axe extends Weapons {

    private static final int SOUND = 5;
    private WeaponType baseDamage;
    private int num = 5;

    public Axe(String name, int minDamage, int maxDamage, int numberOfSockets) {
        super(name, minDamage, maxDamage, numberOfSockets);
    }

//    public Axe(String name) {
//        super(name, SOUND, num, numberOfSockets);
//    }

    @Override
    protected void setMinDamage(int minDamage) {
        super.setMinDamage(minDamage);
    }

    @Override
    protected void setMaxDamage(int maxDamage) {
        super.setMaxDamage(maxDamage);
    }

    @Override
    protected void setNumberOfSockets(int numberOfSockets) {
        super.setNumberOfSockets(numberOfSockets);
    }
}
