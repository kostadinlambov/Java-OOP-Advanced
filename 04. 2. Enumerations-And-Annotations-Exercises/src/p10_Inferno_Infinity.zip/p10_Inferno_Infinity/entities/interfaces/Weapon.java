package p10_Inferno_Infinity.entities.interfaces;

public interface Weapon {

    void addGem(int socketIndex, String gemType);

    void removeGem(int socketIndex);
}
