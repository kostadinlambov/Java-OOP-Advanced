package pr03_04_Barracks.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
