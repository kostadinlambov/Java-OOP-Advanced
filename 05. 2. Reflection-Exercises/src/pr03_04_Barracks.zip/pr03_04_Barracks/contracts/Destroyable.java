package pr03_04_Barracks.contracts;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
