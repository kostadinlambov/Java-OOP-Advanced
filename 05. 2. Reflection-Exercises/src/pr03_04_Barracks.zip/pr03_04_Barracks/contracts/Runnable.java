package pr03_04_Barracks.contracts;

public interface Runnable {
	void run();
}
