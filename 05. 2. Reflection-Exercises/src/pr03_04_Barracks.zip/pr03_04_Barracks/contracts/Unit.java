package pr03_04_Barracks.contracts;

public interface Unit extends Destroyable, Attacker {
}
