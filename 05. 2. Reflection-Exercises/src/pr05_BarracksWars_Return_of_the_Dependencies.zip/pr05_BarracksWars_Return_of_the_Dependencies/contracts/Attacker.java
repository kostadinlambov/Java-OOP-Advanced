package pr05_BarracksWars_Return_of_the_Dependencies.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
