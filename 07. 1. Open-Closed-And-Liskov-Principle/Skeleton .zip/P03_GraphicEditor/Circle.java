package P03_GraphicEditor;

/**
 * Created by Buro on 3.4.2017 г..
 */
public class Circle extends Shape {
}
