package P03_GraphicEditor;

public class Rectangle extends Shape {
}
