package P03_GraphicEditor;

public class Shape {
}
