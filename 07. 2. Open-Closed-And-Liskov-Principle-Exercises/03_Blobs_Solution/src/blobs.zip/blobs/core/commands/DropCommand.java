package blobs.core.commands;

import blobs.core.BaseCommand;

public class DropCommand extends BaseCommand {
    @Override
    public String execute() {
        return null;
    }
}
