package blobs.core.commands;

import blobs.core.BaseCommand;

public class PassCommand extends BaseCommand {
    @Override
    public String execute() {
        return null;
    }
}
