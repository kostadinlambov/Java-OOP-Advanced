package blobs.interfaces;

public interface Attack {

    void execute(Blob attacker, Blob target);
}
