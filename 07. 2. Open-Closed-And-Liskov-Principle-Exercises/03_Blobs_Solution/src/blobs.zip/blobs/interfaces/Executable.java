package blobs.interfaces;

public interface Executable {

    String execute();
}
