package blobs.interfaces;

public interface InputReader {

    String readLine();
}