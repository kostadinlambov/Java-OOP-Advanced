package blobs.interfaces;

public interface Observer {

    void update();
}
