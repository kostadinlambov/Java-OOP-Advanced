package blobs.interfaces;

public interface Runnable {

    void run();
}
