package p01_Logger_Chain_of_Responsibility;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
