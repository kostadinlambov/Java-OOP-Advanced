package p01_Logger_Chain_of_Responsibility.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
