package p01_Logger_Chain_of_Responsibility.interfaces;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}