package p02_command;

public enum LogType {
    ATTACK, MAGIC, TARGET, ERROR, EVENT;
}
