package p02_command.interfaces;

public interface Command {
    void execute();
}
