package p02_command.interfaces;

public interface Executor {
    void executeCommand(Command command);
}
