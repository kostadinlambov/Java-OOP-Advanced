package p02_command.interfaces;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}