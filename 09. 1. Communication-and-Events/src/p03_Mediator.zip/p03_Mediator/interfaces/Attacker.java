package p03_Mediator.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
