package p03_Mediator.interfaces;

public interface Command {
    void execute();
}
