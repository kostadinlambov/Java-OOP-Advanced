package p03_Mediator.interfaces;

public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}