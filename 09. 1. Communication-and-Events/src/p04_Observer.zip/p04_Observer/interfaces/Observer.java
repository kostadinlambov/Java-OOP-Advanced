package p04_Observer.interfaces;

public interface Observer {
    void update(int reward);
}
