package p01_Event_Implementation;

public interface NameChangeListener {
   void handleChangedName(NameChange event);
}
