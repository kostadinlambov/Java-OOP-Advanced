package p02_Kings_Gambit.engine;

import p02_Kings_Gambit.GroupOfGuards;
import p02_Kings_Gambit.commands.AttackExecutable;
import p02_Kings_Gambit.commands.KillExecutable;
import p02_Kings_Gambit.factories.WarriorFactoryImpl;
import p02_Kings_Gambit.interfaces.*;
import p02_Kings_Gambit.io.ConsoleInputreader;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Engine implements Runnable {
    private static final GuardsGroup guardsGroup = new GroupOfGuards();
    private static final WarriorFactory warriorFactory = new WarriorFactoryImpl();
    private static final InputReader reader = new ConsoleInputreader();

    private OutputWriter writer;

    public Engine(OutputWriter writer) {
       // this.reader = reader;
        this.writer = writer;
    }

    @Override
    public void run() {
        try {
            readInput();
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InstantiationException | IOException | InvocationTargetException e) {
            e.printStackTrace();
        }

        while (true) {
            String[] tokens = reader.readLine().split("\\s+");

            if ("End".equalsIgnoreCase(tokens[0])) {
                break;
            }

            String command = tokens[0];

            switch (command) {
                case "Attack":
                    Executable attackExecutable = new AttackExecutable(guardsGroup);
                    attackExecutable.execute();
//                    guardsGroup.getGuards().stream().filter(x -> x.getClass().getSimpleName()
// .equalsIgnoreCase("King")).forEach(newKing -> {
//                        newKing.handle();
//                        guardsGroup.groupAttack();
//                    });
                    //  guardsGroup.groupAttack();
                    break;
                case "Kill":
                    String name = tokens[1];
//                    guardsGroup.remove(name);

                    Executable killExecutable = new KillExecutable(name, guardsGroup);
                    killExecutable.execute();
                    break;
            }
        }
    }

    private static void readInput() throws ClassNotFoundException, NoSuchMethodException,
            InstantiationException, IllegalAccessException, InvocationTargetException, IOException {

        String[] kingsName = reader.readLine().split("\\s+");
        // Warrior king = warriorFactory.createWarrior("King", kingsName);
        addWarrior(kingsName, "King");

        String[] guardsArr = reader.readLine().split("\\s+");
        addWarrior(guardsArr, "RoyalGuards");

        String[] footmanArr = reader.readLine().split("\\s+");
        addWarrior(footmanArr, "Footman");
    }

    private static void addWarrior(String[] warriorArr, String warriorType) throws ClassNotFoundException,
            NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        for (int i = 0; i < warriorArr.length; i++) {
            Warrior warrior = warriorFactory.createWarrior(warriorType, warriorArr[i]);
            guardsGroup.addMember(warrior);
        }
    }
}
