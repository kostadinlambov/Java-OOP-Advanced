package p02_Kings_Gambit.interfaces;

public interface CommandInterpreter {
    Executable interpretCommand(String commandName);
}
