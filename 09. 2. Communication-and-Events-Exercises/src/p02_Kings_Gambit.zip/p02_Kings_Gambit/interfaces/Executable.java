package p02_Kings_Gambit.interfaces;

public interface Executable {
    void execute();
}
