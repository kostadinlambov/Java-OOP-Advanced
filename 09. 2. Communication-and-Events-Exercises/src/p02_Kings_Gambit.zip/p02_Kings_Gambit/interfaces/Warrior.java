package p02_Kings_Gambit.interfaces;

public interface Warrior {
    String getName();

    void handle();
}
