package p02_Kings_Gambit.interpreters;

import p02_Kings_Gambit.interfaces.CommandInterpreter;
import p02_Kings_Gambit.interfaces.Executable;

public class CommandInterpreterImpl implements CommandInterpreter {

    @Override
    public Executable interpretCommand(String commandName) {
        return null;
    }
}
