package p02_Kings_Gambit;

import p02_Kings_Gambit.interfaces.GuardsGroup;
import p02_Kings_Gambit.interfaces.Warrior;
import p02_Kings_Gambit.warriors.Footman;
import p02_Kings_Gambit.warriors.King;
import p02_Kings_Gambit.warriors.RoyalGuards;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    private static final GuardsGroup guardsGroup = new GroupOfGuards();

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String kingsName = reader.readLine();
        Warrior king = new King(kingsName);

        String[] guardsArr = reader.readLine().split("\\s+");
        addGuard(guardsArr);

        String[] footmanArr = reader.readLine().split("\\s+");
        addFootman(footmanArr);

        while (true) {
            String[] tokens = reader.readLine().split("\\s+");

            if ("End".equalsIgnoreCase(tokens[0])) {
                break;
            }
            
            String command = tokens[0];

            switch (command) {
                case "Attack":
                    king.handle();
                    guardsGroup.groupAttack();
                    break;
                case "Kill":
                    String name = tokens[1];
                    guardsGroup.remove(name);
                    break;
            }
        }
    }

    private static void addFootman(String[] footmanArr) {
        for (int i = 0; i < footmanArr.length; i++) {
            Warrior guard = new Footman(footmanArr[i]);
            guardsGroup.addMember(guard);
        }
    }

    private static void addGuard(String[] guardsArr) {

        for (int i = 0; i < guardsArr.length; i++) {
            Warrior guard = new RoyalGuards(guardsArr[i]);
            guardsGroup.addMember(guard);
        }
    }
}
