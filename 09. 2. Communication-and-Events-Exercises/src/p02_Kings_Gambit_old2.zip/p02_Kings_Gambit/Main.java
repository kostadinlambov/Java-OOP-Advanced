package p02_Kings_Gambit;

import p02_Kings_Gambit.factories.WarriorFactoryImpl;
import p02_Kings_Gambit.interfaces.GuardsGroup;
import p02_Kings_Gambit.interfaces.InputReader;
import p02_Kings_Gambit.interfaces.Warrior;
import p02_Kings_Gambit.interfaces.WarriorFactory;
import p02_Kings_Gambit.io.ConsoleInputreader;
import p02_Kings_Gambit.warriors.Footman;
import p02_Kings_Gambit.warriors.King;
import p02_Kings_Gambit.warriors.RoyalGuards;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;

public class Main {
    private static final GuardsGroup guardsGroup = new GroupOfGuards();
    private static final WarriorFactory warriorFactory = new WarriorFactoryImpl();
    private static final InputReader reader = new ConsoleInputreader();

    public static void main(String[] args) throws NoSuchMethodException, InstantiationException,
            IOException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {

        String kingsName = reader.readLine();
        Warrior king = warriorFactory.createWarrior("King", kingsName);

        readInput();

        while (true) {
            String[] tokens = reader.readLine().split("\\s+");

            if ("End".equalsIgnoreCase(tokens[0])) {
                break;
            }

            String command = tokens[0];

            switch (command) {
                case "Attack":
                    king.handle();
                    guardsGroup.groupAttack();
                    break;
                case "Kill":
                    String name = tokens[1];
                    guardsGroup.remove(name);
                    break;
            }
        }
    }

    private static void readInput() throws ClassNotFoundException, NoSuchMethodException,
            InstantiationException, IllegalAccessException, InvocationTargetException, IOException {
        String[] guardsArr = reader.readLine().split("\\s+");
        addWarrior(guardsArr, "RoyalGuards");

        String[] footmanArr = reader.readLine().split("\\s+");
        addWarrior(footmanArr, "Footman");
    }

    private static void addWarrior(String[] warriorArr, String warriorType) throws ClassNotFoundException,
            NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        for (int i = 0; i < warriorArr.length; i++) {
            Warrior warrior = warriorFactory.createWarrior(warriorType, warriorArr[i]);
            guardsGroup.addMember(warrior);
        }
    }

}
