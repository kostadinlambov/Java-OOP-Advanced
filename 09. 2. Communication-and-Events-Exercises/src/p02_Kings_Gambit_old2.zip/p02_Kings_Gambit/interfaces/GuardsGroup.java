package p02_Kings_Gambit.interfaces;

public interface GuardsGroup {
    void addMember(Warrior guard);

    void remove(String name);

    void groupAttack();
}
