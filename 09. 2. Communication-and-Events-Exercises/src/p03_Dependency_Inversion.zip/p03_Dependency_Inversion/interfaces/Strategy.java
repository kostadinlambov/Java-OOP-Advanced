package p03_Dependency_Inversion.interfaces;

public interface Strategy {
    int calculate(int firstOperand, int secondOperand);
}
