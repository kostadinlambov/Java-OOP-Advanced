package p04_Work_Force.commands;

import p04_Work_Force.interfaces.Executable;

public class CreateCommand implements Executable {



    @Override
    public void execute() {

    }
}
