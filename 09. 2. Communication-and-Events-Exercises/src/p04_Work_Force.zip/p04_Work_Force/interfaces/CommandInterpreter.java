package p04_Work_Force.interfaces;



public interface CommandInterpreter {
    Executable interpretCommand(String commandName);
}
