package p04_Work_Force.interfaces;

public interface Employee {
    String getName();

    int getWorkHoursPerWeek();
}
