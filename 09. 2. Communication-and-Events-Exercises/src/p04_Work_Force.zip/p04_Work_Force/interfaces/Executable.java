package p04_Work_Force.interfaces;

public interface Executable {
    void execute();
}
