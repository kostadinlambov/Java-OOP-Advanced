package p05_Kings_Gambit_Extended.interfaces;

public interface CommandInterpreter {
    Executable interpretCommand(String commandName);
}
