package p05_Kings_Gambit_Extended.interfaces;

public interface Executable {
    void execute();
}
