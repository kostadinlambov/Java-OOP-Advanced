package p05_Kings_Gambit_Extended.interfaces;

public interface Warrior {
    int getHitsCount();

    void setHitsCount(int hitsCount);

    String getName();

    void handle();
}
