package p05_Kings_Gambit_Extended.interpreters;

import p05_Kings_Gambit_Extended.interfaces.CommandInterpreter;
import p05_Kings_Gambit_Extended.interfaces.Executable;

public class CommandInterpreterImpl implements CommandInterpreter {
    @Override
    public Executable interpretCommand(String commandName) {
        return null;
    }
}
