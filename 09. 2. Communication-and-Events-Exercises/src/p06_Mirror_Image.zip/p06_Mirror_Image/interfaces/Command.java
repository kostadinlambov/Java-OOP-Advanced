package p06_Mirror_Image.interfaces;

public interface Command {
    void execute();
}
