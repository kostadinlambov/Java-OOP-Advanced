package p06_Mirror_Image.interfaces;

public interface Executor {
    void executeCommand(Command command);
}
