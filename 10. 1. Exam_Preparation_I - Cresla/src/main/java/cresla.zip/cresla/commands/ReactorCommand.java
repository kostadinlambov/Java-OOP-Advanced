package cresla.commands;

import cresla.interfaces.Executable;

import java.util.List;

public class ReactorCommand extends BaseCommand {





    @Override
    public String reactorCommand(List<String> arguments) {
        return null;
    }
}
