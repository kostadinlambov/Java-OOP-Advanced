package cresla.entities.modules;


public class CooldownSystem extends BaseAbsorberModule {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
