package cresla.entities.reactors;

import cresla.interfaces.Container;
import cresla.interfaces.EnergyModule;

public class CryoReactor extends BaseReactor {

    private int cryoProductionIndex;


    public CryoReactor(int id, Container container, int cryoProductionIndex) {
        super(id, container);
        this.cryoProductionIndex = cryoProductionIndex;
    }

    @Override
    public long getTotalEnergyOutput() {
        return super.getTotalEnergyOutput() * this.cryoProductionIndex;
    }


    @Override
    public void addEnergyModule(EnergyModule energyModule) {
        super.addEnergyModule(energyModule);
    }

}
