package cresla.interfaces;

public interface Executable {
    void execute();
}
