package cresla.interfaces;

public interface Identifiable {
    int getId();
}
