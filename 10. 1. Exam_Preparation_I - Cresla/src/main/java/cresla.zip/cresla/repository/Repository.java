package cresla.repository;

public interface Repository  {
}
