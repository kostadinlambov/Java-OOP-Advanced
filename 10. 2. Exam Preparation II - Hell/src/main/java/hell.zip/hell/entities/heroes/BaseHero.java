package hell.entities.heroes;

import hell.entities.miscellaneous.HeroInventory;
import hell.interfaces.Hero;
import hell.interfaces.Item;
import hell.interfaces.Recipe;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public abstract class BaseHero implements Hero {

    private static final String INVENTORY_PACKAGE_PATH = "hell.entities.miscellaneous.";
    private static final String INVENTORY_CLASS_NAME = "HeroInventory";


    private String name;
    private int strength;
    private int agility;
    private int intelligence;
    private int hitpoints;
    private int damage;
    private Collection<Item> items;

    protected BaseHero(String name, int strength, int agility, int intelligence, int hitpoints, int damage) {
        this.name = name;
        this.strength = strength;
        this.agility = agility;
        this.intelligence = intelligence;
        this.hitpoints = hitpoints;
        this.damage = damage;
        this.items = new ArrayList<>();
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public long getStrength() {
        return this.strength;
    }

    @Override
    public long getAgility() {
        return this.agility;
    }

    @Override
    public long getIntelligence() {
        return this.intelligence;
    }

    @Override
    public long getHitPoints() {
        return this.hitpoints;
    }

    @Override
    public long getDamage() {
        return this.damage;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Collection<Item> getItems() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        // Class<?> inventoryClass = Class.forName(INVENTORY_PACKAGE_PATH + INVENTORY_CLASS_NAME);
        Class<?> inventoryClass = HeroInventory.class;
        Constructor constructor = inventoryClass.getDeclaredConstructor();
        HeroInventory heroInventoryInstance = (HeroInventory) constructor.newInstance();

        Field heroInventoryField = inventoryClass.getDeclaredFields()[0];
        heroInventoryField.setAccessible(true);

        Map<String, Item> commonItemsMap = (Map<String, Item>) heroInventoryField.get(heroInventoryInstance);
        Collection<Item> herocommonItems = commonItemsMap.values();
        this.items = herocommonItems;
        return this.items;
    }

    @Override
    public void addItem(Item item) {
        this.items.add(item);
    }

    @Override
    public void addRecipe(Recipe recipe) {
        this.items.add(recipe);
    }
}
