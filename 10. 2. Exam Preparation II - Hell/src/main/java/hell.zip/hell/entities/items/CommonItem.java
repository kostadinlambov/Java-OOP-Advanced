package hell.entities.items;

public class CommonItem extends BaseItem {

    public CommonItem(String name, int strengthBonus, int agilityBonus, int intelligenceBonus, int hitpointsBonus, int damageBonus) {
        super(name, strengthBonus, agilityBonus, intelligenceBonus, hitpointsBonus, damageBonus);
    }
}
