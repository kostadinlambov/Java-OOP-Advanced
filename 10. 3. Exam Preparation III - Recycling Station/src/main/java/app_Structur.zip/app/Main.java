package app;

import app.waste_disposal.ProcessingDataImpl;
import app.waste_disposal.contracts.InputReader;
import app.waste_disposal.contracts.OutputWriter;
import app.waste_disposal.contracts.ProcessingData;
import app.waste_disposal.core.Engine;
import app.waste_disposal.core.WasteManager;
import app.waste_disposal.io.ConsoleInputReader;
import app.waste_disposal.io.ConsoleOutputWriter;

public class Main {
    public static void main(String[] args) {

        InputReader reader = new ConsoleInputReader();
        OutputWriter writer = new ConsoleOutputWriter();
        ProcessingData processingData = new ProcessingDataImpl();
        WasteManager wasteManager = new WasteManager(processingData);

        Runnable engine = new Engine(reader, writer, wasteManager);

        engine.run();
    }
}
