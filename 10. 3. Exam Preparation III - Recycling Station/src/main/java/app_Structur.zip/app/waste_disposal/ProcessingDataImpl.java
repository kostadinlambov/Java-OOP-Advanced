package app.waste_disposal;

import app.waste_disposal.contracts.ProcessingData;

public class ProcessingDataImpl implements ProcessingData {
    private double energyBalance;
    private double capitalBalance;


    public ProcessingDataImpl() {
        this.energyBalance = 0;
        this.capitalBalance = 0;
    }

    public void setEnergyBalance(double energyBalance) {
        this.energyBalance = energyBalance;
    }

    public void setCapitalBalance(double capitalBalance) {
        this.capitalBalance = capitalBalance;
    }

    @Override
    public double getEnergyBalance() {
        return 0;
    }

    @Override
    public double getCapitalBalance() {
        return 0;
    }
}
