package app.waste_disposal.core;

import app.waste_disposal.ProcessingDataImpl;
import app.waste_disposal.contracts.InputReader;
import app.waste_disposal.contracts.OutputWriter;
import app.waste_disposal.contracts.ProcessingData;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Engine implements Runnable {

    private static final String TERMINATE_COMMAND = "TimeToRecycle";

    private List<String> params;
    InputReader reader;
    OutputWriter writer;
    WasteManager manager;


    public Engine(InputReader reader, OutputWriter writer, WasteManager wasteManager) {
        this.reader = reader;
        this.writer = writer;
        this.params = new ArrayList<>();
        this.manager = wasteManager;
    }

    @Override
    public void run() {

        while (true) {
            List<String> tokens = new ArrayList<>(Arrays.asList(this.reader.readLine().split("\\s+")));

            this.dispatchCommand(tokens.get(0), tokens.stream().skip(1).collect(Collectors.toList()));


            if (TERMINATE_COMMAND.equalsIgnoreCase(tokens.get(0))) {
                break;
            }
        }
    }

    private void dispatchCommand(String command, List<String> tokens) {
        this.params = tokens;

        //Class<?> commandClass = Class.forName(COMMAND_CLASS_PATH + command + COMMAND_CLASS_NAME_SUFFIX);

        switch (command) {
            case "ProcessGarbage":
                writer.writeLine(this.manager.processGarbage(this.params));
                break;
            case "Status":
                writer.writeLine(this.manager.status());
                break;
        }
    }


}
