package app.waste_disposal.core;

import app.waste_disposal.ProcessingDataImpl;
import app.waste_disposal.contracts.ProcessingData;

import java.util.List;

public class WasteManager {

    ProcessingData processingData;

    public WasteManager(ProcessingData processingData) {
        this.processingData = processingData;
    }


    public String processGarbage (List<String> params){
        return null;
    }



    public String status(){
        return null;
    }




}
