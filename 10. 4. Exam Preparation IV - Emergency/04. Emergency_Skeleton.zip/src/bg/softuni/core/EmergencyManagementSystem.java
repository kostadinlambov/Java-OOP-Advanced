package bg.softuni.core;

public class EmergencyManagementSystem {

    public EmergencyManagementSystem() {

    }

    public String registerPropertyEmergency() {
        return null;
    }

    public String registerHealthEmergency() {
        return null;
    }

    public String registerOrderEmergency() {
        return null;
    }

    public String registerFireServiceCenter() {
        return null;
    }

    public String registerMedicalServiceCenter() {
        return null;
    }

    public String registerPoliceServiceCenter() {
        return null;
    }

    public String processEmergencies() {
        return null;
    }

    public String emergencyReport() {
        return null;
    }
}
