package app.contracts;

public interface Special {

    void setOwner(Hero owner);

    void update();

    void refresh();

}
